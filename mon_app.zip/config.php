<?php
return [
    'db' => [
        'host' => 'db',
        'dbname' => 'my_database',
        'username' => 'my_user',
        'password' => 'my_password',
    ]
];
